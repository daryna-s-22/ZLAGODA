﻿using System;
using System.Configuration;
using System.Data.SQLite;
using System.Security.Cryptography;

namespace ZLAGODA.Services
{
    /// <summary>
    /// Сервіс для реєстрації, аутентифікації та авторизації користувачів.
    /// Використовує PBKDF2 з унікальною сіллю, зберігає лише хеші паролів.
    /// </summary>
    public static class AuthService
    {
        private const int SaltSize = 16;
        private const int HashSize = 20;
        private const int Iterations = 10000;
        private static readonly string ConnectionString;

        // Статичний конструктор для ініціалізації рядка підключення і створення таблиці
        static AuthService()
        {
            // Читаємо з App.config
            ConnectionString = ConfigurationManager.ConnectionStrings["UsersDb"].ConnectionString;

            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();
            const string createTableSql = @"
                CREATE TABLE IF NOT EXISTS Users (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    username      TEXT    NOT NULL UNIQUE,
                    password_hash TEXT    NOT NULL,
                    salt          TEXT    NOT NULL,
                    role          TEXT    NOT NULL
                );";
            using var cmd = new SQLiteCommand(createTableSql, conn);
            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// Реєстрація нового користувача із хешуванням пароля.
        /// Повертає true, якщо успішно, false — якщо ім'я вже існує.
        /// </summary>
        public static bool Register(string username, string password, string role)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(role))
                throw new ArgumentException("Username, password and role must be provided.");

            // Генеруємо унікальну сіль
            var saltBytes = new byte[SaltSize];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(saltBytes);
            }

            // Хешуємо пароль
            string hashBase64;
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, saltBytes, Iterations, HashAlgorithmName.SHA256))
            {
                var hash = pbkdf2.GetBytes(HashSize);
                hashBase64 = Convert.ToBase64String(hash);
            }

            var saltBase64 = Convert.ToBase64String(saltBytes);

            // Вставка в БД
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();
            const string insertSql = @"
                INSERT INTO Users (username, password_hash, salt, role)
                VALUES (@u, @h, @s, @r);";
            using var cmd = new SQLiteCommand(insertSql, conn);
            cmd.Parameters.AddWithValue("@u", username);
            cmd.Parameters.AddWithValue("@h", hashBase64);
            cmd.Parameters.AddWithValue("@s", saltBase64);
            cmd.Parameters.AddWithValue("@r", role);

            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (SQLiteException ex) when (ex.ResultCode == SQLiteErrorCode.Constraint)
            {
                // Ім'я користувача вже існує
                return false;
            }
        }

        /// <summary>
        /// Аутентифікація користувача. Повертає роль при успіху, або null при невдачі.
        /// </summary>
        public static string? Authenticate(string username, string password)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
                return null;

            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();
            const string querySql = @"
                SELECT password_hash, salt, role
                FROM Users
                WHERE username = @u;";
            using var cmd = new SQLiteCommand(querySql, conn);
            cmd.Parameters.AddWithValue("@u", username);
            using var reader = cmd.ExecuteReader();
            if (!reader.Read())
                return null;

            var storedHash = reader.GetString(0);
            var storedSalt = reader.GetString(1);
            var role = reader.GetString(2);

            var saltBytes = Convert.FromBase64String(storedSalt);
            string hashBase64;
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, saltBytes, Iterations, HashAlgorithmName.SHA256))
            {
                var hash = pbkdf2.GetBytes(HashSize);
                hashBase64 = Convert.ToBase64String(hash);
            }

            return hashBase64 == storedHash ? role : null;
        }
        /// <summary>
        /// Повертає список усіх користувачів (username + role).
        /// </summary>
        public static List<(string Username, string Role)> GetAllUsers()
        {
            var list = new List<(string, string)>();
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();
            const string sql = @"
        SELECT username, role
        FROM Users
        ORDER BY username;";
            using var cmd = new SQLiteCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add((
                    reader.GetString(0),  // username
                    reader.GetString(1)   // role
                ));
            }
            return list;
        }

    }
}

// App.config connection string example:
// <connectionStrings>
//   <add name="UsersDb" connectionString="Data Source=users.db;Version=3;" providerName="System.Data.SQLite" />
// </connectionStrings>