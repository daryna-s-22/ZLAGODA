﻿
namespace ZLAGODA.Services
{
    public static class SessionService
    {
        public static string CurrentUsername { get; private set; } = "";
        public static string CurrentRole { get; private set; } = "";

        public static void StartSession(string username, string role)
        {
            CurrentUsername = username;
            CurrentRole = role;
        }

        public static void EndSession()
        {
            CurrentUsername = "";
            CurrentRole = "";
        }
    }
}
