﻿using System.Configuration;
using System.Data.SQLite;
using ZLAGODA.Entities;

namespace ZLAGODA.Services
{
    public static class StoreProductService
    {
        private static readonly string ConnectionString;

        static StoreProductService()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["AccountingDb"].ConnectionString;

            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string createTableSql = @"
                CREATE TABLE IF NOT EXISTS StoreProducts (
                    upc                 VARCHAR(12) PRIMARY KEY NOT NULL,
                    ref_upc             VARCHAR(12) NULL,
                    product_id          INTEGER NOT NULL,
                    quantity            INTEGER NOT NULL,
                    selling_price       DECIMAL(13, 4) NOT NULL,
                    is_promotional      BOOLEAN NOT NULL,
                    FOREIGN KEY (ref_upc) REFERENCES StoreProducts(upc)
                        ON DELETE SET NULL
                        ON UPDATE CASCADE,
                    FOREIGN KEY (product_id) REFERENCES Products(id)
                        ON DELETE NO ACTION
                        ON UPDATE CASCADE
                );";

            using var createCmd = new SQLiteCommand(createTableSql, conn);
            createCmd.ExecuteNonQuery();
        }

        public static void AddStoreProduct(
            string upc,
            string? ref_upc,
            int product_id,
            int quantity,
            decimal selling_price,
            bool is_promotional)
        {
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            if (!string.IsNullOrWhiteSpace(ref_upc))
            {
                const string checkRefUpcSql = @"
                    SELECT COUNT(1)
                    FROM StoreProducts
                    WHERE upc = @ref_upc;";

                using var checkRefUpcCmd = new SQLiteCommand(checkRefUpcSql, conn);
                checkRefUpcCmd.Parameters.AddWithValue("@ref_upc", ref_upc);
                var exists = Convert.ToInt32(checkRefUpcCmd.ExecuteScalar()) > 0;
                if (!exists)
                    throw new InvalidOperationException($"Promotional UPC {ref_upc} does not exist.");
            }

            const string checkProductSql = @"
                SELECT COUNT(1)
                FROM Products
                WHERE id = @product_id;";

            using (var checkProductCmd = new SQLiteCommand(checkProductSql, conn))
            {
                checkProductCmd.Parameters.AddWithValue("@product_id", product_id);
                var exists = Convert.ToInt32(checkProductCmd.ExecuteScalar()) > 0;
                if (!exists)
                    throw new InvalidOperationException($"Product with ID {product_id} does not exist.");
            }

            var s = new StoreProduct(upc, ref_upc, product_id, quantity, selling_price, is_promotional);

            const string insertSql = @"
                INSERT INTO StoreProducts (upc, ref_upc, product_id, quantity, selling_price, is_promotional)
                VALUES (@upc, @ref_upc, @product_id, @quantity, @selling_price, @is_promotional);";

            using var insertCmd = new SQLiteCommand(insertSql, conn);
            insertCmd.Parameters.AddWithValue("@upc", s.UPC);
            insertCmd.Parameters.AddWithValue("@ref_upc", string.IsNullOrEmpty(s.refUPC) ? DBNull.Value : s.refUPC);
            insertCmd.Parameters.AddWithValue("@product_id", s.ProductId);
            insertCmd.Parameters.AddWithValue("@quantity", s.Quantity);
            insertCmd.Parameters.AddWithValue("@selling_price", s.SellingPrice);
            insertCmd.Parameters.AddWithValue("@is_promotional", s.IsPromotional ? 1 : 0);

            insertCmd.ExecuteNonQuery();
        }

        public static void DeleteStoreProduct(
            string upc)
        {
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string countSql = @"
                SELECT COUNT(*)
                FROM Sales 
                WHERE upc = @upc";

            using var countCmd = new SQLiteCommand(countSql, conn);
            countCmd.Parameters.AddWithValue("@upc", upc);

            long upcCount = (long)countCmd.ExecuteScalar();

            if (upcCount > 0)
            {
                Console.WriteLine("Products in the store cannot be deleted.");
                return;
            }

            const string searchSql = @"
                SELECT ref_upc
                FROM StoreProducts
                WHERE ref_upc = @upc;";

            using var searchCmd = new SQLiteCommand(searchSql, conn);
            searchCmd.Parameters.AddWithValue("@upc", upc);

            object? searchResult = searchCmd.ExecuteScalar();

            if (searchResult != null || searchResult != DBNull.Value)
            {
                Console.WriteLine("Product in the store has promotional and cannot be deleted.");
                return;
            }

            const string deleteSql = @"
                DELETE
                FROM StoreProducts
                WHERE upc = @upc;";

            using var deleteCmd = new SQLiteCommand(deleteSql, conn);
            deleteCmd.Parameters.AddWithValue("@upc", upc);
            deleteCmd.ExecuteNonQuery();
        }
    }
}

