﻿using System.Configuration;
using System.Data.SQLite;
using ZLAGODA.Entities;

namespace ZLAGODA.Services
{
    public static class CheckService
    {
        private static readonly string ConnectionString;
        static CheckService()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["AccountingDb"].ConnectionString;

            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string createTableSql = @"
                CREATE TABLE IF NOT EXISTS Checks (
                    check_id          VARCHAR(10) PRIMARY KEY NOT NULL,
                    employee_id       VARCHAR(10)   NOT NULL,
                    customer_card_id  VARCHAR(13)   NULL,
                    check_issue_date  VARCHAR(10)   NOT NULL,
                    total_check_value DECIMAL(13,4) NOT NULL,
                    vat               DECIMAL(13,4) NOT NULL,
                    FOREIGN KEY (employee_id) REFERENCES Employees(id)
                        ON UPDATE CASCADE
                        ON DELETE NO ACTION,
                    FOREIGN KEY (customer_card_id) REFERENCES CustomerCards(card_id)
                        ON UPDATE CASCADE
                        ON DELETE NO ACTION
                );";

            using var createCmd = new SQLiteCommand(createTableSql, conn);
            createCmd.ExecuteNonQuery();
        }

        public static bool AddCheck(
            string check_id, 
            string employee_id,
            string? customer_card_id,
            string check_issue_date,
            decimal total_check_value,
            decimal vat
            )
        {
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string checkEmployeeIdExistSql = @"
                SELECT COUNT(1)
                FROM Employees
                WHERE id = @employee_id;";

            using (var checkEmployeeIdExistCmd = new SQLiteCommand(checkEmployeeIdExistSql, conn))
            {
                checkEmployeeIdExistCmd.Parameters.AddWithValue("@employee_id", employee_id);
                var exists = Convert.ToInt32(checkEmployeeIdExistCmd.ExecuteScalar()) > 0;
                if (!exists)
                    throw new InvalidOperationException($"Employee with ID {employee_id} does not exist.");
            }

            const string checkCustCardExistSql = @"
                SELECT COUNT(1)
                FROM CustomerCards
                WHERE card_id = @customer_card_id;";

            if (string.IsNullOrEmpty(customer_card_id) == false)
            {

                using (var checkCustCardExistCmd = new SQLiteCommand(checkCustCardExistSql, conn))
                {
                    checkCustCardExistCmd.Parameters.AddWithValue("@customer_card_id", customer_card_id);
                    var exists = Convert.ToInt32(checkCustCardExistCmd.ExecuteScalar()) > 0;
                    if (!exists)
                        throw new InvalidOperationException($"Customer card with ID {customer_card_id} does not exist.");
                }
            }

            var c = new Check(check_id, employee_id, customer_card_id, check_issue_date, total_check_value, vat);

            const string insertSql = @"
                INSERT INTO Checks (check_id, employee_id, customer_card_id, check_issue_date, total_check_value, vat)
                VALUES (@check_id, @employee_id, @customer_card_id, @check_issue_date, @total_check_value, @vat);";

            using var insertCmd = new SQLiteCommand(insertSql, conn);
            insertCmd.Parameters.AddWithValue("@check_id", c.CheckId);
            insertCmd.Parameters.AddWithValue("@employee_id", c.EmployeeId);
            insertCmd.Parameters.AddWithValue("@customer_card_id", string.IsNullOrEmpty(c.CustomerCardId) ? DBNull.Value : c.CustomerCardId);
            insertCmd.Parameters.AddWithValue("@check_issue_date", c.CheckIssueDate);
            insertCmd.Parameters.AddWithValue("@total_check_value", c.TotalCheckValue);
            insertCmd.Parameters.AddWithValue("@vat", c.VAT);


            try
            {
                insertCmd.ExecuteNonQuery();
                return true;
            }
            catch (SQLiteException ex) when (ex.ResultCode == SQLiteErrorCode.Constraint)
            {
                return false;
            }
        }

        public static void DeleteCheck(
            string check_id)
        {
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string deleteSql = @"
                DELETE
                FROM Checks
                WHERE check_id = @check_id;";

            using var cmd = new SQLiteCommand(deleteSql, conn);
            cmd.Parameters.AddWithValue("@check_id", check_id);
            cmd.ExecuteNonQuery();
        }
    }
}
