﻿using System.Configuration;
using System.Data.SQLite;
using ZLAGODA.Entities;

namespace ZLAGODA.Services
{
    public static class EmployeeService
    {
        private static readonly string ConnectionString;
        static EmployeeService()
        {
            /*Не забути додати перевірку на вік*/

            ConnectionString = ConfigurationManager.ConnectionStrings["AccountingDb"].ConnectionString;

            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string createTableSql = @"
                CREATE TABLE IF NOT EXISTS Employees (
                    id               VARCHAR(10) PRIMARY KEY NOT NULL,
                    surname          VARCHAR(50) NOT NULL,
                    name             VARCHAR(50) NOT NULL,
                    patronymic       VARCHAR(50) NULL,
                    role             VARCHAR(10) NOT NULL,
                    salary           DECIMAL(13, 4) NOT NULL,
                    birth_date       VARCHAR(10) NOT NULL,
                    start_date       VARCHAR(10) NOT NULL,
                    phone_number     VARCHAR(13) NOT NULL,
                    city             VARCHAR(50) NOT NULL,
                    street           VARCHAR(50) NOT NULL,
                    zip_code         VARCHAR(9) NOT NULL
                );";

            using var createCmd = new SQLiteCommand(createTableSql, conn);
            createCmd.ExecuteNonQuery();
        }

        public static void AddEmployee(
            string id,
            string surname,
            string name,
            string? patronymic, 
            string role,
            decimal salary,
            string birth_date,
            string start_date,
            string phone_number,
            string city,
            string street,
            string zip_code)
        {

            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            var e = new Employee(id, surname, name, patronymic, role, salary, birth_date, start_date, phone_number, city, street, zip_code);

            const string insertSql = @"
                INSERT INTO Employees (id, surname, name, patronymic, role, salary, birth_date, start_date, phone_number, city, street, zip_code)
                VALUES (@id, @surname, @name, @patronymic, @role, @salary, @birth_date, @start_date, @phone_number, @city, @street, @zip_code);";

            using var insertCmd = new SQLiteCommand(insertSql, conn);
            insertCmd.Parameters.AddWithValue("@id", e.Id);
            insertCmd.Parameters.AddWithValue("@surname", e.Surname);
            insertCmd.Parameters.AddWithValue("@name", e.Name);
            insertCmd.Parameters.AddWithValue("@patronymic", string.IsNullOrEmpty(patronymic) ? DBNull.Value : e.Patronymic);
            insertCmd.Parameters.AddWithValue("@role", e.Role);
            insertCmd.Parameters.AddWithValue("@salary", e.Salary);
            insertCmd.Parameters.AddWithValue("@birth_date", e.BirthDate);
            insertCmd.Parameters.AddWithValue("@start_date", e.StartDate);
            insertCmd.Parameters.AddWithValue("@phone_number", e.PhoneNumber);
            insertCmd.Parameters.AddWithValue("@city", e.City);
            insertCmd.Parameters.AddWithValue("@street", e.Street);
            insertCmd.Parameters.AddWithValue("@zip_code", e.ZipCode);
            insertCmd.ExecuteNonQuery();
        }

        public static void DeleteEmployee(
            string id)
        {
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string countSql = @"
                SELECT COUNT(*)
                FROM Checks
                WHERE employee_id = @id;";

            using var countCmd = new SQLiteCommand(countSql, conn);
            countCmd.Parameters.AddWithValue("@id", id);
            long checkCount = (long)countCmd.ExecuteScalar();

            if (checkCount > 0)
            {
                Console.WriteLine("Employee record linked to check and cannot be deleted.");
                return;
            }

            const string deleteSql = @"
                DELETE
                FROM Employees
                WHERE id = @id;";

            using var deleteCmd = new SQLiteCommand(deleteSql, conn);
            deleteCmd.Parameters.AddWithValue("@id", id);
            deleteCmd.ExecuteNonQuery();
        }
    }
}
