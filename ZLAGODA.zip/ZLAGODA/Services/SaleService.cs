﻿using System.Configuration;
using System.Data.SQLite;
using ZLAGODA.Entities;

namespace ZLAGODA.Services
{
    public static class SaleService
    {
        private static readonly string ConnectionString;

        static SaleService()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["AccountingDb"].ConnectionString;

            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string createTableSql = @"
                CREATE TABLE IF NOT EXISTS Sales (
                    upc            VARCHAR(12) NOT NULL,
                    check_id       VARCHAR(10) NOT NULL,
                    quantity       INTEGER NOT NULL,
                    selling_price  DECIMAL(13,4) NOT NULL,
                    PRIMARY KEY (upc, check_id),
                    FOREIGN KEY (upc) REFERENCES StoreProducts(upc)
                        ON UPDATE CASCADE
                        ON DELETE NO ACTION,
                    FOREIGN KEY (check_id) REFERENCES Checks(check_id)
                        ON UPDATE CASCADE
                        ON DELETE CASCADE
                );";

            using var createCmd = new SQLiteCommand(createTableSql, conn);
            createCmd.ExecuteNonQuery();
        }

        public static void AddSale(
            string upc, 
            string check_id, 
            int quantity,
            decimal selling_price)
        {
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            if (!string.IsNullOrWhiteSpace(upc))
            { 
                const string checkUpcSql = @"
                    SELECT COUNT(1)
                    FROM StoreProducts
                    WHERE upc = @upc;";

                using var checkUpcCmd = new SQLiteCommand(checkUpcSql, conn);
                checkUpcCmd.Parameters.AddWithValue("@upc", upc);

                var exists = Convert.ToInt32(checkUpcCmd.ExecuteScalar()) > 0;
                if (!exists)
                    throw new InvalidOperationException($"UPC {upc} does not exist.");
            } else
            {
                throw new InvalidOperationException($"UPC {upc} will not null.");
            }

            const string checkCheckIdSql = @"
                SELECT COUNT(1)
                FROM Checks 
                WHERE check_id = @check_id;";
            using (var checkCheckIdCmd = new SQLiteCommand(checkCheckIdSql, conn))
            {
                checkCheckIdCmd.Parameters.AddWithValue("@check_id", check_id);
                var exists = Convert.ToInt32(checkCheckIdCmd.ExecuteScalar()) > 0;
                if (!exists)
                    throw new InvalidOperationException($"Check with ID {check_id} does not exist.");
            }

            var s = new Sale(upc, check_id, quantity, selling_price);

            const string insertSql = @"
                INSERT INTO Sales (upc, check_id, quantity, selling_price)
                VALUES (@upc, @check_id, @quantity, @selling_price);";

            using var insertCmd = new SQLiteCommand(insertSql, conn);
            insertCmd.Parameters.AddWithValue("@upc", s.UPC);
            insertCmd.Parameters.AddWithValue("@check_id", s.CheckId);
            insertCmd.Parameters.AddWithValue("@quantity", s.Quantity);
            insertCmd.Parameters.AddWithValue("@selling_price", s.SellingPrice);

            insertCmd.ExecuteNonQuery();
        }

        public static void DeleteSale(
            string upc, 
            string check_id)
        {
            // Не чіпати!
            // Не можна видаляти (можливо зробити запит на чек)

            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string deleteSql = @"
                DELETE
                FROM Sales
                WHERE upc = @upc AND check_id = @check_id;";

            using var deleteCmd = new SQLiteCommand(deleteSql, conn);
            deleteCmd.Parameters.AddWithValue("@upc", upc);
            deleteCmd.Parameters.AddWithValue("@check_id", check_id);
            deleteCmd.ExecuteNonQuery();
        }
    }
}
