﻿using System.Configuration;
using System.Data.SQLite;
using ZLAGODA.Entities;

namespace ZLAGODA.Services
{
    public static class CustomerCardService
    {
        private static readonly string ConnectionString;

        static CustomerCardService()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["AccountingDb"].ConnectionString;

            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string createTableSql = @"
                CREATE TABLE IF NOT EXISTS CustomerCards (
                    card_id         VARCHAR(13) PRIMARY KEY NOT NULL,
                    surname         VARCHAR(50) NOT NULL,
                    name            VARCHAR(50) NOT NULL,
                    patronymic      VARCHAR(50) NULL,
                    phone_number    VARCHAR(13) NOT NULL,
                    city            VARCHAR(50) NULL,
                    street          VARCHAR(50) NULL,
                    zip_code        VARCHAR(9)  NULL,
                    percent         INTEGER NOT NULL
                );";

            using var createCmd = new SQLiteCommand(createTableSql, conn);
            createCmd.ExecuteNonQuery();
        }

        public static bool AddCustomerCard(
            string card_id,
            string surname,
            string name,
            string? patronymic,
            string phone_number,
            string? city,
            string? street,
            string? zip_code,
            int percent)
        {
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            var c = new CustomerCard(card_id, surname, name, patronymic, phone_number, city, street, zip_code, percent);

            const string insertSql = @"
                INSERT INTO CustomerCards (card_id, surname, name, patronymic, phone_number, city, street, zip_code, percent)
                VALUES (@card_id, @surname, @name, @patronymic, @phone_number, @city, @street, @zip_code, @percent);";

            using var insertCmd = new SQLiteCommand(insertSql, conn);
            insertCmd.Parameters.AddWithValue("@card_id", c.CardId);
            insertCmd.Parameters.AddWithValue("@surname", c.Surname);
            insertCmd.Parameters.AddWithValue("@name", c.Name);
            insertCmd.Parameters.AddWithValue("@patronymic", string.IsNullOrEmpty(c.Patronymic) ? DBNull.Value : c.Patronymic);
            insertCmd.Parameters.AddWithValue("@phone_number", c.PhoneNumber);
            insertCmd.Parameters.AddWithValue("@city", string.IsNullOrEmpty(c.City) ? DBNull.Value : c.City);
            insertCmd.Parameters.AddWithValue("@street", string.IsNullOrEmpty(c.Street) ? DBNull.Value : c.Street);
            insertCmd.Parameters.AddWithValue("@zip_code", string.IsNullOrEmpty(c.ZipCode) ? DBNull.Value : c.ZipCode);
            insertCmd.Parameters.AddWithValue("@percent", c.Percent);

            try
            {
                insertCmd.ExecuteNonQuery();
                return true;
            }
            catch (SQLiteException ex) when (ex.ResultCode == SQLiteErrorCode.Constraint)
            {
                return false;
            }
        }

        public static List<(string, string, string)> GetAllCustomerCards()
        {
            var list = new List<(string, string, string)>();

            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            const string getSql = @"
                SELECT card_id, surname, name 
                FROM CustomerCards 
                ORDER BY card_id;";

            using var viewCmd = new SQLiteCommand(getSql, conn);
            using var reader = viewCmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add((
                    reader.GetString(0),
                    reader.GetString(1),
                    reader.GetString(2)
                ));
            }
            return list;
        }

        public static void DeleteCustomerCard(string card_id)
        {
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string countSql = @"
                SELECT COUNT(*)
                FROM Checks
                WHERE customer_card_id = @card_id;";

            using var countCmd = new SQLiteCommand(countSql, conn);
            countCmd.Parameters.AddWithValue("@card_id", card_id);

            long checkCount = (long)countCmd.ExecuteScalar();

            if (checkCount > 0)
            {
                Console.WriteLine("Customer card linked to check and cannot be deleted.");
                return;
            }

            const string deleteSql = @"
                DELETE
                FROM CustomerCards
                WHERE card_id = @card_id;";

            using var deleteCmd = new SQLiteCommand(deleteSql, conn);
            deleteCmd.Parameters.AddWithValue("@card_id", card_id);
            deleteCmd.ExecuteNonQuery();
        }
    }
}
