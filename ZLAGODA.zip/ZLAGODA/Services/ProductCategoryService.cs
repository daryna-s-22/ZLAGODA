﻿using System.Configuration;
using System.Data.SQLite;
using ZLAGODA.Entities;

namespace ZLAGODA.Services
{
    public static class ProductCategoryService
    {
        private static readonly string ConnectionString;

        static ProductCategoryService()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["AccountingDb"].ConnectionString;

            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            const string createTableSql = @"
                CREATE TABLE IF NOT EXISTS ProductCategories (
                    id   INTEGER PRIMARY KEY AUTOINCREMENT,
                    name VARCHAR(50) NOT NULL UNIQUE
                );";

            using var createCmd = new SQLiteCommand(createTableSql, conn);
            createCmd.ExecuteNonQuery();
        }

        public static bool AddProductCategory(
            string name)
        {
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            const string insertSql = @"
                INSERT INTO ProductCategories (name)
                VALUES (@name);";

            var c = new ProductCategory(1, name);

            using var insertCmd = new SQLiteCommand(insertSql, conn);
            insertCmd.Parameters.AddWithValue("@name", c.Name);

            try
            {
                insertCmd.ExecuteNonQuery();
                return true;
            }
            catch (SQLiteException ex) when (ex.ResultCode == SQLiteErrorCode.Constraint)
            {
                return false;
            }
        }

        public static void DeleteProductCategory(
            int id)
        {
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            const string countSql = @"
                SELECT COUNT(*)
                FROM Products
                WHERE category_id = @id;";

            using var countCmd = new SQLiteCommand(countSql, conn);
            countCmd.Parameters.AddWithValue("@id", id);

            long productCount = (long)countCmd.ExecuteScalar();

            if (productCount > 0)
            {
                Console.WriteLine("Category contains products and cannot be deleted.");
                return;
            }

            const string deleteSql = @"
                DELETE
                FROM ProductCategories
                WHERE id = @id;";

            using var deleteCmd = new SQLiteCommand(deleteSql, conn);
            deleteCmd.Parameters.AddWithValue("@id", id);
            deleteCmd.ExecuteNonQuery();
        }
    }
}

