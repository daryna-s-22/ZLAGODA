﻿using System.Configuration;
using System.Data.SQLite;
using ZLAGODA.Entities;

namespace ZLAGODA.Services
{
    public static class ProductService
    {
        private static readonly string ConnectionString;

        static ProductService()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["AccountingDb"].ConnectionString;

            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string createTableSql = @"
                CREATE TABLE IF NOT EXISTS Products (
                    id             INTEGER PRIMARY KEY AUTOINCREMENT,
                    name           VARCHAR(50) NOT NULL,
                    description    VARCHAR(100) NOT NULL,
                    manufacturer   VARCHAR(100) NOT NULL,
                    category_id    INTEGER NOT NULL,
                    FOREIGN KEY (category_id) REFERENCES ProductCategories(id) 
                        ON UPDATE CASCADE ON
                        DELETE NO ACTION
                );";

            using var createCmd = new SQLiteCommand(createTableSql, conn);
            createCmd.ExecuteNonQuery();
        }

        public static bool AddProduct(
            string name,
            string description,
            string manufacturer,
            int category_id)
        {
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string checkCategoryProductIdSql = @"
                SELECT COUNT(1)
                FROM ProductCategories
                WHERE id = @category_id;";

            using (var checkCategoryProductIdCmd = new SQLiteCommand(checkCategoryProductIdSql, conn))
            {
                checkCategoryProductIdCmd.Parameters.AddWithValue("@category_id", category_id);
                var exists = Convert.ToInt32(checkCategoryProductIdCmd.ExecuteScalar()) > 0;
                if (!exists)
                    throw new InvalidOperationException($"Product with ID {category_id} does not exist.");
            }

            var p = new Product(1, name, description, manufacturer, category_id);

            const string insertSql = @"
                INSERT INTO Products (name, description, manufacturer, category_id)
                VALUES (@name, @description, @manufacturer, @category_id);";

            using var insertCmd = new SQLiteCommand(insertSql, conn);
            insertCmd.Parameters.AddWithValue("@name", p.Name);
            insertCmd.Parameters.AddWithValue("@description", p.Description);
            insertCmd.Parameters.AddWithValue("@manufacturer", p.Manufacturer);
            insertCmd.Parameters.AddWithValue("@category_id", p.CategoryId);

            try
            {
                insertCmd.ExecuteNonQuery();
                return true;
            }
            catch (SQLiteException ex) when (ex.ResultCode == SQLiteErrorCode.Constraint)
            {
                return false;
            }
        }

        public static void DeleteProduct(
            int id)
        {
            using var conn = new SQLiteConnection(ConnectionString);
            conn.Open();

            using var pragmaCmd = new SQLiteCommand("PRAGMA foreign_keys = ON;", conn);
            pragmaCmd.ExecuteNonQuery();

            const string countSql = @"
                SELECT COUNT(*)
                FROM StoreProducts
                WHERE product_id = @id;";

            using var countCmd = new SQLiteCommand(countSql, conn);
            countCmd.Parameters.AddWithValue("@id", id);

            long storeProductCount = (long)countCmd.ExecuteScalar();

            if (storeProductCount > 0)
            {
                Console.WriteLine("The product is sold in the store and cannot be deleted.");
                return;
            }

            const string deleteSql = @"
                DELETE
                FROM Products
                WHERE id = @id;";

            using var deleteCmd = new SQLiteCommand(deleteSql, conn);
            deleteCmd.Parameters.AddWithValue("@id", id);
            deleteCmd.ExecuteNonQuery();
        }
    }
}


