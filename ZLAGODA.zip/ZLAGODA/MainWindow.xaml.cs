﻿using System.Windows;

namespace ZLAGODA
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            View.LoginWindow login = new View.LoginWindow();
            login.Show();
            this.Close();
        }

        private void Guest_Click(object sender, RoutedEventArgs e)
        {
            View.GuestWindow guest = new View.GuestWindow();
            guest.Show();
            this.Close();
        }

        private void MyTest_Click(object sender, RoutedEventArgs e)
        {
            View.MyTestWindow myTest = new View.MyTestWindow();
            myTest.Show();
            this.Close();
        }
    }
}
