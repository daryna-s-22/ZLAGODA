﻿namespace ZLAGODA.Entities
{
    public class Sale
    {
        private string _upc = string.Empty;
        private string _check_id = string.Empty;
        private int _quantity = 0;
        private decimal _selling_price = 0.0m;

        public Sale(
            string upc,
            string check_id,
            int quantity,
            decimal selling_price
            )
        {
            UPC = upc;
            CheckId = check_id;
            Quantity = quantity;
            SellingPrice = selling_price;
        }

        public string UPC
        {
            get => _upc;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 12)
                {
                    _upc = value;
                }
                else
                {
                    throw new ArgumentException("Product UPC must be between 1 and 12 characters.");
                }
            }
        }

        public string CheckId
        {
            get => _check_id;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 10)
                {
                    _check_id = value;
                }
                else
                {
                    throw new ArgumentException("Check ID must be between 1 and 10 characters.");
                }
            }
        }

        public int Quantity
        {
            get => _quantity;
            set
            {
                if (value >= 0)
                {
                    _quantity = value;
                }
                else
                {
                    throw new ArgumentException("Product number must be a non-negative integer.");
                }
            }
        }

        public decimal SellingPrice
        {
            get => _selling_price;
            set
            {
                if (value >= 0)
                {
                    _selling_price = value;
                }
                else
                {
                    throw new ArgumentException("Selling price must be a non-negative number.");
                }
            }
        }
    }
}

