﻿namespace ZLAGODA.Entities
{
    public class Employee
    {
        private string _id = string.Empty;
        private string _surname = string.Empty;
        private string _name = string.Empty;
        private string? _patronymic = null;
        private string _role = string.Empty;
        private decimal _salary = 0.0m;
        private string _birth_date = string.Empty;
        private string _start_date = string.Empty;
        private string _phone_number = string.Empty;
        private string _city = string.Empty;
        private string _street = string.Empty;
        private string _zip_code = string.Empty;

        public Employee(
            string id,
            string surname,
            string name,
            string? patronymic,
            string role,
            decimal salary,
            string birth_date,
            string start_date,
            string phone_number,
            string city,
            string street,
            string zip_code)
        {
            Id = id;
            Surname = surname;
            Name = name;
            Patronymic = patronymic;
            Role = role;
            Salary = salary;
            BirthDate = birth_date;
            StartDate = start_date;
            PhoneNumber = phone_number;
            City = city;
            Street = street;
            ZipCode = zip_code;
        }

        public string Id
        {
            get => _id;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 10)
                    _id = value;
                else
                    throw new ArgumentException("Employee ID must be between 1 and 10 characters.");
            }
        }

        public string Surname
        {
            get => _surname;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 50)
                    _surname = value;
                else
                    throw new ArgumentException("Surname must be between 1 and 50 characters.");
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 50)
                    _name = value;
                else
                    throw new ArgumentException("Name must be between 1 and 50 characters.");
            }
        }

        public string? Patronymic
        {
            get => _patronymic;
            set
            {
                if (value == null || value.Length <= 50)
                    _patronymic = value;
                else
                    throw new ArgumentException("Patronymic must be 50 characters or fewer.");
            }
        }

        public string Role
        {
            get => _role;
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                    _role = value;
                else
                    throw new ArgumentException("Role must not be empty.");
            }
        }

        public decimal Salary
        {
            get => _salary;
            set
            {
                if (value >= 0)
                    _salary = value;
                else
                    throw new ArgumentException("Salary must be non-negative.");
            }
        }

        public string BirthDate
        {
            get => _birth_date;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length == 10)
                    _birth_date = value;
                else
                    throw new ArgumentException("Birth date must be exactly 10 characters (e.g. yyyy-mm-dd).");
            }
        }

        public string StartDate
        {
            get => _start_date;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length == 10)
                    _start_date = value;
                else
                    throw new ArgumentException("Start date must be exactly 10 characters (e.g. yyyy-mm-dd).");
            }
        }

        public string PhoneNumber
        {
            get => _phone_number;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length == 13 && value.StartsWith("+"))
                    _phone_number = value;
                else
                    throw new ArgumentException("Phone number must be 13 characters and start with '+'.");
            }
        }

        public string City
        {
            get => _city;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 50)
                    _city = value;
                else
                    throw new ArgumentException("City must be between 1 and 50 characters.");
            }
        }

        public string Street
        {
            get => _street;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 50)
                    _street = value;
                else
                    throw new ArgumentException("Street must be between 1 and 50 characters.");
            }
        }

        public string ZipCode
        {
            get => _zip_code;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 9)
                    _zip_code = value;
                else
                    throw new ArgumentException("ZIP code must be between 1 and 9 characters.");
            }
        }
    }
}

