﻿namespace ZLAGODA.Entities
{
    public class ProductCategory
    {
        private int _id = 0;
        private string _name = string.Empty;

        public ProductCategory(
            int _id,
            string _name)
        {
            Id = _id;
            Name = _name;
        }

        public int Id
        {
            get => _id;
            set
            {
                if (value > 0)
                {
                    _id = value;
                }
                else
                {
                    throw new ArgumentException("Product category ID must be a positive integer.");
                }
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 50)
                {
                    _name = value;
                }
                else
                {
                    throw new ArgumentException("Product category name must be between 1 and 50 characters.");
                }
            }
        }
    }
}

