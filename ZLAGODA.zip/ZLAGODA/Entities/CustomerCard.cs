﻿namespace ZLAGODA.Entities
{
    public class CustomerCard
    {
        private string _card_id = string.Empty;
        private string _surname = string.Empty;
        private string _name = string.Empty;
        private string? _patronymic = null;
        private string _phone_number = string.Empty;
        private string? _city = null;
        private string? _street = null;
        private string? _zip_code = null;
        private int _percent = 0;
        
        public CustomerCard(
            string card_id,
            string surname,
            string name,
            string? patronymic,
            string phone_number,
            string? city,
            string? street,
            string? zip_code,
            int percent)
        {
            CardId = card_id;
            Surname = surname;
            Name = name;
            Patronymic = patronymic;
            PhoneNumber = phone_number;
            City = city;
            Street = street;
            ZipCode = zip_code;
            Percent = percent;
        }

        public string CardId
        {
            get => _card_id;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length < 14)
                    _card_id = value;
                else
                    throw new ArgumentException("Customer card ID must be 1–13 characters.");
            }
        }

        public string Surname
        {
            get => _surname;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length < 51)
                    _surname = value;
                else
                    throw new ArgumentException("Surname must be between 1 and 50 characters.");
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length < 51)
                    _name = value;
                else
                    throw new ArgumentException("Name must be between 1 and 50 characters.");
            }
        }

        public string? Patronymic
        {
            get => _patronymic;
            set
            {
                if (value == null || value.Length < 51)
                    _patronymic = value;
                else
                    throw new ArgumentException("Patronymic must be 50 characters or fewer.");
            }
        }

        public string PhoneNumber
        {
            get => _phone_number;
            set
            {
                if (value.Length == 13 && value.StartsWith("+"))
                    _phone_number = value;
                else
                    throw new ArgumentException("Phone number must be in format '+XXXXXXXXXXXX'.");
            }
        }

        public string? City
        {
            get => _city;
            set
            {
                if (value == null || value.Length < 51)
                    _city = value;
                else
                    throw new ArgumentException("City must be 50 characters or fewer.");
            }
        }

        public string? Street
        {
            get => _street;
            set
            {
                if (value == null || value.Length < 51)
                    _street = value;
                else
                    throw new ArgumentException("Street must be 50 characters or fewer.");
            }
        }

        public string? ZipCode
        {
            get => _zip_code;
            set
            {
                if (value == null || value.Length < 10)
                    _zip_code = value;
                else
                    throw new ArgumentException("ZIP code must be between 1 and 9 characters.");
            }
        }

        public int Percent
        {
            get => _percent;
            set
            {
                if (value >= 0 && value <= 100)
                    _percent = value;
                else
                    throw new ArgumentException("Percent must be between 0 and 100.");
            }
        }
    }
}

