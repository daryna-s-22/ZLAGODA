﻿namespace ZLAGODA.Entities
{
    public class Check
    {
        private string _check_id = string.Empty;
        private string _employee_id = string.Empty;
        private string? _customer_card_id = null;
        private string _check_issue_date = string.Empty;
        private decimal _total_check_value = 0.0m;
        private decimal _vat = 0.0m;

        public Check(
            string check_id,
            string employee_id,
            string? customer_card_id,
            string check_issue_date,
            decimal total_check_value,
            decimal vat)
        {
            CheckId = check_id;
            EmployeeId = employee_id;
            CustomerCardId = customer_card_id;
            CheckIssueDate = check_issue_date;
            TotalCheckValue = total_check_value;
            VAT = vat;
        }

        public string CheckId
        {
            get => _check_id;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 10)
                {
                    _check_id = value;
                }
                else
                {
                    throw new ArgumentException("Check ID must be between 1 and 10 characters.");
                }
            }
        }

        public string EmployeeId
        {
            get => _employee_id;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 10)
                {
                    _employee_id = value;
                }
                else
                {
                    throw new ArgumentException("Employee ID must be between 1 and 10 characters.");
                }
            }
        }

        public string? CustomerCardId
        {
            get => _customer_card_id;
            set
            {
                if (value == null || value.Length <= 13)
                {
                    _customer_card_id = value;
                }
                else
                {
                    throw new ArgumentException("Customer ID must be 13 characters or fewer.");
                }
            }
        }

        public string CheckIssueDate
        {
            get => _check_issue_date;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length == 10)
                {
                    _check_issue_date = value;
                }
                else
                {
                    throw new ArgumentException("Check issue date must be 10 characters (e.g. 'yyyy-mm-dd').");
                }
            }
        }

        public decimal TotalCheckValue
        {
            get => _total_check_value;
            set
            {
                if (value >= 0)
                {
                    _total_check_value = value;
                }
                else
                {
                    throw new ArgumentException("Total amount must be non-negative.");
                }
            }
        }

        public decimal VAT
        {
            get => _vat;
            set
            {
                if (value >= 0)
                {
                    _vat = value;
                }
                else
                {
                    throw new ArgumentException("VAT must be non-negative.");
                }
            }
        }
    }
}
