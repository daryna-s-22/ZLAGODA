﻿namespace ZLAGODA.Entities
{
    public class StoreProduct
    {
        private string _upc = string.Empty;
        private string? _ref_upc = null;
        private int _product_id = 0;
        private int _quantity = 0;
        private decimal _selling_price = 0.0m;
        private bool _is_promotional = false;

        public StoreProduct(
            string upc,
            string? ref_upc,
            int product_id,
            int quantity,
            decimal selling_price,
            bool is_promotional)
        {
            UPC = upc;
            refUPC = ref_upc;
            ProductId = product_id;
            Quantity = quantity;
            SellingPrice = selling_price;
            IsPromotional = is_promotional;
        }

        public string UPC
        {
            get => _upc;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 12)
                {
                    _upc = value;
                }
                else
                {
                    throw new ArgumentException("Product UPC must be between 1 and 12 characters.");
                }
            }
        }

        public string? refUPC
        {
            get => _ref_upc;
            set
            {
                if (IsPromotional)
                {
                    if (!string.IsNullOrWhiteSpace(value) && value.Length <= 12)
                    {
                        _ref_upc = value;
                    }
                    else
                    {
                        throw new ArgumentException("Promotional UPC must be between 1 and 12 characters.");
                    }
                }
                else
                {
                    _ref_upc = null; // Clear value if no promo
                }
            }
        }

        public int ProductId
        {
            get => _product_id;
            set
            {
                if (value > 0)
                {
                    _product_id = value;
                }
                else
                {
                    throw new ArgumentException("Product ID must be a positive integer.");
                }
            }
        }

        public int Quantity
        {
            get => _quantity;
            set
            {
                if (value >= 0)
                {
                    _quantity = value;
                }
                else
                {
                    throw new ArgumentException("Product total number must be non-negative.");
                }
            }
        }

        public decimal SellingPrice
        {
            get => _selling_price;
            set
            {
                if (value > 0)
                {
                    _selling_price = value;
                }
                else
                {
                    throw new ArgumentException("Selling price must be greater than 0.");
                }
            }
        }

        public bool IsPromotional
        {
            get => _is_promotional;
            set => _is_promotional = value;
        }
    }
}

