﻿namespace ZLAGODA.Entities
{
    public class Product
    {
        private int _id = 0;
        private string _name = string.Empty;
        private string _description = string.Empty;
        private string _manufacturer = string.Empty;
        private int _category_id = 0;

        public Product(
            int id,
            string name,
            string description,
            string manufacturer,
            int category_id)
        {
            Id = id;
            Name = name;
            Description = description;
            Manufacturer = manufacturer;
            CategoryId = category_id;
        }

        public int Id
        {
            get => _id;
            set
            {
                if (value > 0)
                    _id = value;
                else
                    throw new ArgumentException("Product ID must be a positive integer.");
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 50)
                    _name = value;
                else
                    throw new ArgumentException("Product name must be between 1 and 50 characters.");
            }
        }

        public string Description
        {
            get => _description;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 100)
                    _description = value;
                else
                    throw new ArgumentException("Product description must be between 1 and 100 characters.");
            }
        }

        public string Manufacturer
        {
            get => _manufacturer;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 100)
                    _manufacturer = value;
                else
                    throw new ArgumentException("Manufacturer name must be between 1 and 100 characters.");
            }
        }

        public int CategoryId
        {
            get => _category_id;
            set
            {
                if (value > 0)
                    _category_id = value;
                else
                    throw new ArgumentException("Product category ID must be a positive integer.");
            }
        }
    }
}

