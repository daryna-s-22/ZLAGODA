﻿using System.Windows;
using System.Windows.Controls;
using ZLAGODA.Services;

namespace ZLAGODA.View
{
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameBox.Text;
            string password = PasswordBox.Password;
            string role = (RoleComboBox.SelectedItem as ComboBoxItem)?.Content.ToString()!;

            bool ok = AuthService.Register(username, password, role);
            MessageBox.Show(
                ok
                  ? "Користувача успішно зареєстровано!"
                  : "Це ім'я вже існує.",
                "Реєстрація",
                MessageBoxButton.OK,
                ok ? MessageBoxImage.Information : MessageBoxImage.Warning
            );

            if (ok)
            {
                // після успішної реєстрації повертаємось до списку користувачів
                var usersWin = new UsersWindow();
                usersWin.Show();
                this.Close();
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            // Повертаємося в ManagerWindow
            var manager = new ManagerWindow();
            manager.Show();
            this.Close();
        }
    }
}