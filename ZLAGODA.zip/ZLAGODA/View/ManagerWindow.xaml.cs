﻿using System.Windows;
using ZLAGODA.Services;

namespace ZLAGODA.View
{
    public partial class ManagerWindow : Window
    {
        public ManagerWindow()
        {
            InitializeComponent();
            SessionInfo.Text =
           $"User: {SessionService.CurrentUsername}   Role: {SessionService.CurrentRole}";
        }

        private void ViewUsers_Click(object sender, RoutedEventArgs e)
        {
            // Закриваємо ManagerWindow і відкриваємо UsersWindow
            var usersWindow = new UsersWindow();
            usersWindow.Show();
            this.Close();
        }

        private void RegisterUser_Click(object sender, RoutedEventArgs e)
        {
            // Закриваємо ManagerWindow і відкриваємо RegisterWindow
            var regWindow = new RegisterWindow();
            regWindow.Show();
            this.Close();
        }
    }
}