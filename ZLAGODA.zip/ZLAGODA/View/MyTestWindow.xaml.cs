﻿using System.Collections.Generic;
using System.Windows;
using ZLAGODA.Services;

namespace ZLAGODA.View
{
    /// <summary>
    /// Interaction logic for MyTestWindow.xaml
    /// </summary>
    public partial class MyTestWindow : Window
    {
        public MyTestWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadCustomerCards();
        }

        private void LoadCustomerCards()
        {
            var list = CustomerCardService.GetAllCustomerCards();
            var items = new List<object>();
            foreach (var (CustomerCardId, CustomerSurname, CustomerName) in list)
                items.Add(new { CustomerCardId, CustomerSurname, CustomerName });
            CustomerCardsDataGrid.ItemsSource = items;
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
