﻿using System.Collections.Generic;
using System.Windows;
using ZLAGODA.Services;

namespace ZLAGODA.View
{
    public partial class UsersWindow : Window
    {
        public UsersWindow()
        {
            InitializeComponent();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadUsers();
        }

        private void LoadUsers()
        {
            var list = AuthService.GetAllUsers();
            var items = new List<object>();
            foreach (var (Username, Role) in list)
                items.Add(new { Username, Role });
            UsersDataGrid.ItemsSource = items;
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            // Повертаємося в ManagerWindow
            var manager = new ManagerWindow();
            manager.Show();
            this.Close();
        }
    }
}
