﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;

namespace ZLAGODA.View
{
    public partial class PrintReportWindow : Window
    {
        public PrintReportWindow()
        {
            InitializeComponent();
        }

        public void Print_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog pd = new PrintDialog();
            if (pd.ShowDialog() == true)
            {
                FlowDocument doc = new FlowDocument();
                doc.Blocks.Add(new Paragraph(new Run("Звіт про продажі")));
                doc.Blocks.Add(new Paragraph(new Run($"Дата: {DateTime.Now.ToShortDateString()}")));
                doc.Blocks.Add(new Paragraph(new Run("• Товар 1 – 10 одиниць")));
                doc.Blocks.Add(new Paragraph(new Run("• Товар 2 – 25 одиниць")));
                doc.Blocks.Add(new Paragraph(new Run("• Загальна сума: 1200 грн")));

                pd.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, "Звіт");
            }
        }

        public void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
