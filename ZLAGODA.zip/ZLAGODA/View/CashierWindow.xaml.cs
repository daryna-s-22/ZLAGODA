﻿using System.Windows;
using ZLAGODA.Services;

namespace ZLAGODA.View
{
    public partial class CashierWindow : Window
    {
        public CashierWindow()
        {
            InitializeComponent();
            SessionInfo.Text =
           $"User: {SessionService.CurrentUsername}   Role: {SessionService.CurrentRole}";
        }

        private void OpenPrintReport_Click(object sender, RoutedEventArgs e)
        {
            var reportWindow = new PrintReportWindow();
            reportWindow.Show();
        }
    }
}
