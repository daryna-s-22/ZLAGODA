﻿using System.Windows;
using ZLAGODA.Services;

namespace ZLAGODA.View
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();   // <- без цього кнопки та поля з XAML не завантажуються!
           
        }

        private void ManagerLogin_Click(object sender, RoutedEventArgs e)
        {
            AttemptLogin("Manager");
        }

        private void CashierLogin_Click(object sender, RoutedEventArgs e)
        {
            AttemptLogin("Cashier");
        }

        private void AttemptLogin(string roleExpected)
        {
            string username = UsernameBox.Text;
            string password = PasswordBox.Password;

            string? role = AuthService.Authenticate(username, password);
            if (role == null)
            {
                MessageBox.Show(
                    "Невірне ім'я користувача або пароль.",
                    "Помилка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
                return;
            }

            if (role != roleExpected)
            {
                MessageBox.Show($"Користувач не має ролі {roleExpected}.", "Доступ заборонено", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            SessionService.StartSession(username, role);

            Window next = role switch
            {
                "Cashier" => new CashierWindow(),
                "Guest" => new GuestWindow(),
                "Manager" => new ManagerWindow(),
                _ => null
            };

            next?.Show();
            this.Close();
        }
    }
}