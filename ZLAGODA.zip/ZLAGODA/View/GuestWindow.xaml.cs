﻿using System.Windows;
using ZLAGODA.Services;

namespace ZLAGODA.View
{
    public partial class GuestWindow : Window
    {
        public GuestWindow()
        {
            InitializeComponent();
            SessionInfo.Text =
           $"User: {SessionService.CurrentUsername}   Role: {SessionService.CurrentRole}";
        }

        private void ViewReceipt_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Попередній перегляд чеку — тут буде PDF / переглядова форма.");
        }

        private void ViewReport_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Попередній перегляд звіту — тут буде табличний звіт.");
        }
    }
}
