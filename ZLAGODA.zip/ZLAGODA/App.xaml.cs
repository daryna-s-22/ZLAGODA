﻿using System.Configuration;
using System.Data.SQLite;
using System.Windows;
using System.Xml.Linq;
using ZLAGODA.Entities;
using ZLAGODA.Services;

namespace ZLAGODA
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            // Додаємо тестового менеджера admin (якщо ще не існує)
            _ = AuthService.Register(
                username: "admin",
                password: "1234",
                role: "Manager"
            );

            //1

            //ProductCategoryService.AddProductCategory("Напої");
            //ProductCategoryService.AddProductCategory("Снеки");
            //ProductCategoryService.AddProductCategory("Побутова хімія");

            //ProductService.AddProduct("Кока-Кола 1л", "Газований напій", "Coca-Cola Company", 1);
            //ProductService.AddProduct("Сік Rich 1л", "Апельсиновий сік", "Sandora", 1);
            //ProductService.AddProduct("Чіпси Lays", "Солоні чіпси", "Lays", 2);
            //ProductService.AddProduct("Сухарики Flint", "Смак бекону", "Flint", 2);
            //ProductService.AddProduct("Пральний порошок Ariel", "Порошок для прання", "P&G", 3);
            //ProductService.AddProduct("Засіб для миття Fairy", "Лимонний аромат", "P&G", 3);

            //StoreProductService.AddStoreProduct("UPC001", null, 1, 50, 45.00m, false);
            //StoreProductService.AddStoreProduct("UPC002", null, 2, 100, 30.00m, false);
            //StoreProductService.AddStoreProduct("UPC003", null, 3, 75, 25.00m, false);
            //StoreProductService.AddStoreProduct("UPC004", null, 4, 40, 120.00m, false);
            //StoreProductService.AddStoreProduct("UPC005", null, 5, 60, 80.00m, false);
            //StoreProductService.AddStoreProduct("UPC006", "UPC004", 4, 1, 96, true);

            //CustomerCardService.AddCustomerCard("0000000000001", "Іванов", "Іван", "Іванович", "+380991112233", "Київ", "Хрещатик", "01001", 5);
            //CustomerCardService.AddCustomerCard("0000000000002", "Петренко", "Олена", null, "+380992223344", "Львів", "Шевченка", "79000", 10);

            //EmployeeService.AddEmployee("E001", "Коваль", "Олег", "Миколайович", "Касир", 15000.00m, "1990-05-12", "2020-03-01", "+380931112233", "Київ", "Бульвар Лесі Українки", "01133");
            //EmployeeService.AddEmployee("E002", "Мельник", "Анна", null, "Менеджер", 20000.00m, "1985-08-23", "2018-06-15", "+380672223344", "Одеса", "Французький бульвар", "65000");

            //CheckService.AddCheck("CHK001", "E001", "0000000000001", "2025-05-28", 144.00m, 24.00m);
            //CheckService.AddCheck("CHK002", "E002", null, "2025-05-27", 96.00m, 16.00m);

            //SaleService.AddSale("UPC001", "CHK001", 2, 45.00m);
            //SaleService.AddSale("UPC002", "CHK001", 1, 30.00m);
            //SaleService.AddSale("UPC005", "CHK002", 1, 80.00m);

            //2

            //CheckService.DeleteCheck("CHK001");
            //CustomerCardService.DeleteCustomerCard("0000000000002");
            //EmployeeService.DeleteEmployee("E001");
            //EmployeeService.DeleteEmployee("E002");

            base.OnStartup(e);
        }
    }
}
